﻿using System.Windows;

namespace ABB.CommonUX.Windows
{
    public partial class Splash : Window
    {
        public string ProductName
        {
            set => ProductNameLabel.Text = value;
        }

        public Splash()
        {
            InitializeComponent();
        }

        public void SetProgress(int value)
        {
            LoadingProgress.Value = value;
        }
    }
}
