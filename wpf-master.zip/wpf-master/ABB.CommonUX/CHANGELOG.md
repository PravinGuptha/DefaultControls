﻿# Changelog

## v0.0.17 (15-04-2019)

#### Breaking changes:
- TextBox inputs label and decription default values changed to NULL

#### Bug Fixes:
- Fix crash when right-clicking or dragging from black ABB bar
- Fix checkbox indeterminate state icon
- Fix NotificationArePopup designer NullReferenceException problem
- Fix file menu, input fields and dropdowns menu hovering behaviours to correct
- Fix MessageBox respects given text
- Fix TextBox height resppects empty label and description

#### Enhancements:
- Move from Aero2 to older Aero to provide W7 support
- Simple validation style for TextBox

---

## v0.0.0 - v.0.0.16
*No changelog for these releases.*

---
