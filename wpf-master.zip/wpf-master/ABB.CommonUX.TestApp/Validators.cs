﻿using System;
using System.Globalization;
using System.Windows.Controls;

namespace ABB.CommonUX.TestApp
{
    public class IntSmallerThan100 : ValidationRule
    { 
        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            if(Int32.TryParse((string)value, out int result))
            {
                if(result < 100)
                {
                    return ValidationResult.ValidResult;
                }
                return new ValidationResult(false, "Too large value, must be < 100");
            }

            return new ValidationResult(false, "Invalid value");
        }
    }
}
