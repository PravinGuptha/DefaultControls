﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace ABB.CommonUX.Windows
{
    public class MessageBoxButton
    {
        public string Text { get; set; }        
        public bool IsDefault { get; set; }
        public bool IsCancel { get; set; }
        public MessageBoxResult Result { get; set; }
    }

    public partial class MessageBox : ModalDialog
    {
        public string Message { get; set; }
        public MessageBoxResult Result { get; set; } = MessageBoxResult.Cancel;

        public MessageBox(string message, List<MessageBoxButton> buttons)
        {
            Message = message;
            DataContext = this;
            InitializeComponent();

            foreach(var btn in buttons)
            {
                var b = new Button
                {
                    Content = btn.Text,
                    Margin = new Thickness(5),
                    IsCancel = btn.IsCancel,
                    IsDefault = btn.IsDefault
                };
                b.SetResourceReference(StyleProperty, btn.IsDefault ? "AbbPrimaryBlackButtonSmall" : "AbbDiscreetBlackButtonSmall");
                b.Click += Btn_Click;
                b.Tag = btn.Result;
                
                ButtonContainer.Children.Add(b);

                if(btn.IsDefault)
                {
                    b.Focus();
                }
            }
        }       

        private void Btn_Click(object sender, RoutedEventArgs e)
        {
            Result = (MessageBoxResult)((Button)sender).Tag;
            Close();
        }
    }
}
