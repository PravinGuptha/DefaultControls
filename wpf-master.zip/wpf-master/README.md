# Introduction 
This project contains ABB CommonUX styles and controls for C# WPF projects.

## Development
Open solution in Visual Studio (2017) and build. It has no external dependencies.

## Todo
* Do a ToggleButtonGroup control to get rid of LeftStyle, MidStyle, RightStyle thing.
* Remove window frame (there is a white bar top (win10)).
* Test with Win xp/7/8.

# Using Library
## Installation
1. Create / Open a WPF project.
2. TODO Install CommonUX NuGet package (Project -> Manage NuGet Packages...).
3. CommonUX style resources need to be included to project through project's App.xaml file.

```xml
<Application> 
    <Application.Resources>
        <ResourceDictionary>
            <ResourceDictionary.MergedDictionaries>
                <ResourceDictionary Source="pack://application:,,,/ABB.CommonUX;component/Styles/Defaults.xaml"/>
                <ResourceDictionary Source="pack://application:,,,/ABB.CommonUX;component/Styles/Controls.xaml"/>
                <ResourceDictionary Source="pack://application:,,,/ABB.CommonUX;component/Generated/Colors.xaml"/>
                <ResourceDictionary Source="pack://application:,,,/ABB.CommonUX;component/Styles/Fonts.xaml"/>                
                <!-- Available themes are Light.xaml or Dark.xaml -->
                <ResourceDictionary Source="pack://application:,,,/ABB.CommonUX;component/Themes/Light.xaml"/>                
            </ResourceDictionary.MergedDictionaries>            
        </ResourceDictionary>
    </Application.Resources>
</Application>
```

# Standard WPF Control Styles
## Button
```xml
<Button Content="Button" Style="{DynamicResource AbbNormalButton}"/> <!-- default is same as 32 -->
<Button Content="Button" Style="{DynamicResource AbbNormalButton32}"/>
<Button Content="Button" Style="{DynamicResource AbbNormalButton40}"/>
<Button Content="Button" Style="{DynamicResource AbbNormalButton48}"/>

<Button Content="Button" Style="{DynamicResource AbbPrimaryButton}"/> <!-- default is same as 32 -->
<Button Content="Button" Style="{DynamicResource AbbPrimaryButton32}"/>
<Button Content="Button" Style="{DynamicResource AbbPrimaryButton40}"/>
<Button Content="Button" Style="{DynamicResource AbbPrimaryButton48}"/>

<Button Content="Button" Style="{DynamicResource AbbPrimaryButtonColor}"/> <!-- default is same as 32 -->
<Button Content="Button" Style="{DynamicResource AbbPrimaryButtonColor32}"/>
<Button Content="Button" Style="{DynamicResource AbbPrimaryButtonColor40}"/>
<Button Content="Button" Style="{DynamicResource AbbPrimaryButtonColor48}"/>

<Button Content="Button" Style="{DynamicResource AbbDiscreetButton}"/> <!-- default is same as 32 -->
<Button Content="Button" Style="{DynamicResource AbbDiscreetButton32}"/>
<Button Content="Button" Style="{DynamicResource AbbDiscreetButton40}"/>
<Button Content="Button" Style="{DynamicResource AbbDiscreetButton48}"/>
```

## CheckBox
```xml
<CheckBox Content="Check" Style="{DynamicResource AbbNormalCheckBox}"/>
```
## ComboBox
```xml
<CheckBox Style="{DynamicResource AbbNormalComboBox}" commonUx:Input.Placeholder="Pick one!"/>
```
## DataGrid
```xml
<DataGrid Style="{DynamicResource AbbNormalDataGrid}"/>
```
## Label
```xml
<Label Style="{DynamicResource AbbNormalLabel}"/>
```
## ListView
```xml
<ListView Style="{DynamicResource AbbListView}">
    <ListView.View>
        <GridView/>        
    </ListView.View>
</ListView>
```
## Menu
```xml
<Menu Style="{DynamicResource AbbFileMenu}">
    <Menu.Resources>
        <Style TargetType="{x:Type MenuItem}" BasedOn="{StaticResource AbbFileMenuItem}"/>
    </Menu.Resources>
</Menu>
```
## PasswordBox
```xml
<PasswordBox Style="{DynamicResource AbbNormalPasswordBox}" />
```
## ProgressBar
```xml
<ProgressBar Style="{DynamicResource AbbNormalProgressBar}"/>
```
## RadioButton
```xml
// Classic radio button look
<RadioButton Content="Radio" GroupName="g1" Style="{DynamicResource AbbNormalRadioButton}"/>

// ToggleButton style radio button
<RadioButton Content="Radio" GroupName="g2" Style="{DynamicResource 
ToggleRadioButtonLeft}"/>
<RadioButton Content="Radio" GroupName="g2" Style="{DynamicResource ToggleRadioButtonMid}"/>
<RadioButton Content="Radio" GroupName="g2" Style="{DynamicResource ToggleRadioButtonRight}"/>
```
## Slider
```xml
<Slider Style="{DynamicResource AbbNormalSlider}"/>
```
## TabControl
```xml
<TabControl Style="{DynamicResource AbbNormalTabControl}"/>
<TabControl Style="{DynamicResource AbbSecondaryTabControl}"/>
<TabControl Style="{DynamicResource AbbNavigationTabControl}"/>
<TabControl Style="{DynamicResource AbbPanelTabItem}"/>
```
## TextBlock
```xml
<TextBlock Style="{DynamicResource AbbNormalTextBlock}"/>
```
## TextBox
```xml
<TextBox Style="{DynamicResource AbbNormalTextBox}"
    commonUx:Input.Label="TextBox label"
    commonUx:Input.Placeholder="Placeholder text"
    commonUx:Input.Description="Some description text"/>

<TextBox Style="{DynamicResource AbbValidationTextBox}"
    commonUx:Input.Label="Magic number"
    commonUx:Input.Placeholder="24"
    commonUx:Input.Description="Should be smaller than 100"/>
```
## ToggleButton
```xml
<ToggleButton Content="Toggle" Style="{DynamicResource AbbNormalToggleButton}"/>
<ToggleButton Content="Toggle" Style="{DynamicResource AbbSwitchToggleButton}"/>
```
## TreeView
```xml
<TreeView Style="{DynamicResource TreeViewAccordion}" />
```

# New Controls
Add following namespace to xaml file to access CommonUX controls

```xml
xmlns:commonUx="clr-namespace:ABB.CommonUX.Controls;assembly=ABB.CommonUX"
```

## DoubleSlider
Slider that can edit two values (lower / upper limit).

Properties

- Value1 - Value of the lower slider.
- Value2 - Value of the upper slider.
```xml
<commonUx:DoubleSlider Minimum="0" Maximum="100" Value1="50" Value2="80"/>
```

## Icon
Control that can be used to display abb icons.

Properties

- Image - abb icon enumeration
```xml
<controls:Icon Image="print"/>
```

## IconButton
Similar to normal Button control, but has a support for abb-icons.

Properties

- Image - abb icon enumeration

```xml
<commonUx:IconButton Content="Button" Image="alarm_bell" Style="{DynamicResource NormalIconButton}"/>
<commonUx:IconButton Content="Button" Image="alarm_bell" Style="{DynamicResource PrimaryIconButton}"/>
<commonUx:IconButton Content="Button" Image="alarm_bell" Style="{DynamicResource DiscreetIconButton}"/>
```

## LoadingIndicator
Control that displays a loading indicator animation.
```xml
<commonUx:LoadingIndicator Style="{DynamicResource LoadingIndicatorSmall}"/>
<commonUx:LoadingIndicator Style="{DynamicResource LoadingIndicatorMedium}"/>
<commonUx:LoadingIndicator Style="{DynamicResource LoadingIndicatorLarge}"/>
```

## MeasureBar
```xml
<commonUx:MeasureBar Label="Label" Unit="Active power (pu)" Value="40" LowWarning="20" HighWarning="80" LowAlarm="10" HighAlarm="90" Minimum="0" Maximum="100"/>
```

## Navigation
```xml
```

## SearchBox
```xml
```
## TabControlClosable
```xml
```
## Tags
```xml
```

## TopBar
Header title bar for applications.

Properties

- **ApplicationName** - Display application name.
- **Identity** - Type of application "identity style".    
    - *Cursor* - Shows red cursor icon.
    - *Icon* - Shows custom application icon.
- **ImageSource** - Image source when using *Icon* identity style.
- **ShowWindowControls** - Adds window dragging, minimize, maximize and close buttons to TopBar. When used, you can remove default window style from application main window (WindowStyle = "None").
```xml
<commonUx:TopBar ApplicationName="Demo Application" ShowWindowControls="True" Identity="Icon" ImageSource="Images/appicon.png"/>
```
                
# Functionality
## Changing Themes
You can swap between dark and light theme using Themes class.
```csharp
// Get current color theme.
var theme = ABB.CommonUX.Themes.GetCurrentTheme(Application.Current);

// Change theme.
ABB.CommonUX.Themes.ChangeTheme(Application.Current, Themes.Theme.Dark);
```
## MessageBox
```csharp
ABB.CommonUX.MessageBox.Show();
```
## ModalDialog
```xml
```
## Notification
```xml
```