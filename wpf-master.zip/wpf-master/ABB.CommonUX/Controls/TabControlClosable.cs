﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace ABB.CommonUX.Controls
{
    public class TabItemClosable : TabItem
    {
        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            var buttonClose = GetTemplateChild("buttonClose") as Button;
            buttonClose.Click += ButtonClose_Click;
        }

        private void ButtonClose_Click(object sender, RoutedEventArgs e)
        {
            RoutedEventArgs args = new RoutedEventArgs(CloseClickedEvent, this);
            RaiseEvent(args);
        }

        public static readonly RoutedEvent CloseClickedEvent =
            EventManager.RegisterRoutedEvent("CloseClicked", RoutingStrategy.Bubble, typeof(RoutedEventHandler), typeof(TabItemClosable));

        public event RoutedEventHandler CloseClicked
        {
            add => AddHandler(CloseClickedEvent, value);
            remove => RemoveHandler(CloseClickedEvent, value);
        }
    }

    public class TabControlClosable : TabControl
    {
        public static readonly RoutedEvent CloseClickedEvent =
            EventManager.RegisterRoutedEvent("CloseClicked", RoutingStrategy.Bubble, typeof(RoutedEventHandler), typeof(TabControlClosable));

        public static readonly RoutedEvent AddTabClickedEvent =
            EventManager.RegisterRoutedEvent("AddTabClicked", RoutingStrategy.Bubble, typeof(RoutedEventHandler), typeof(TabControlClosable));

        public static readonly DependencyProperty NewTabCommandProperty = 
            DependencyProperty.Register("NewTabCommand", typeof(RoutedCommand), typeof(TabControlClosable));

        public TabControlClosable()
        {
            NewTabCommand = new RoutedCommand("NewTabCommand", typeof(TabControlClosable));
            var binding = new CommandBinding { Command = NewTabCommand };
            binding.Executed += AddTabOnExecuted;
            CommandBindings.Add(binding);
        }

        public event RoutedEventHandler CloseClicked
        {
            add => AddHandler(CloseClickedEvent, value);
            remove => RemoveHandler(CloseClickedEvent, value);
        }

        public event RoutedEventHandler AddTabClicked
        {
            add => AddHandler(AddTabClickedEvent, value);
            remove => RemoveHandler(AddTabClickedEvent, value);
        }

        protected override DependencyObject GetContainerForItemOverride()
        {
            var tabitem = new TabItemClosable();
            tabitem.CloseClicked += Tabitem_CloseClicked;
            return tabitem;
        }

        private void Tabitem_CloseClicked(object sender, RoutedEventArgs e)
        {
            var args = new RoutedEventArgs(CloseClickedEvent, e.Source);
            RaiseEvent(args);
        }

        private void AddTabOnExecuted(object sender, ExecutedRoutedEventArgs e)
        {
            var args = new RoutedEventArgs(AddTabClickedEvent, e.Source);
            RaiseEvent(args);
        }

        public ICommand NewTabCommand
        {
            get { return (ICommand)GetValue(NewTabCommandProperty); }
            set { SetValue(NewTabCommandProperty, value); }
        }
    }
}
