﻿using System.Windows;

namespace ABB.CommonUX.Windows
{
    public partial class LoginDialog : Window
    {
        public string ProductName
        {
            set => ProductNameLabel.Text = value;
        }

        public LoginDialog()
        {
            InitializeComponent();
        }

        private void Ok_OnClick(object sender, System.Windows.RoutedEventArgs e)
        {
            Close();
        }
    }
}
