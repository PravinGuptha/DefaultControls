﻿using System.Windows;
using System.Windows.Controls;

namespace ABB.CommonUX.Controls
{
    public class IconButton : Button
    {       
        public IconType Image
        {
            get => (IconType)GetValue(ImageProperty);
            set => SetValue(ImageProperty, value);
        }

        public static readonly DependencyProperty ImageProperty =
            DependencyProperty.Register("Image", typeof(IconType), typeof(IconButton));
    }
}
