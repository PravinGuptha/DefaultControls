﻿using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;

namespace ABB.CommonUX.Controls
{
    public partial class DoubleSlider : UserControl, INotifyPropertyChanged
    {
        private Thumb _thumbLeft;
        private Thumb _thumbRight;

        public DoubleSlider()
        {
            InitializeComponent();
            Loaded += DoubleSlider_Loaded;
            MouseEnter += (sender, args) => { ValueBox.Visibility = Visibility.Visible; };
            MouseLeave += (sender, args) => { ValueBox.Visibility = Visibility.Collapsed; };
        }

        private void DoubleSlider_Loaded(object sender, RoutedEventArgs e)
        {
            _thumbLeft = ((Track)Slider1.Template.FindName("PART_Track", Slider1))?.Thumb;
            _thumbRight = ((Track)Slider2.Template.FindName("PART_Track", Slider2))?.Thumb;
            RefreshHighlight();
        }

        public double Minimum
        {
            get => (double)GetValue(MinimumProperty);
            set => SetValue(MinimumProperty, value);
        }

        public double Maximum
        {
            get => (double)GetValue(MaximumProperty);
            set => SetValue(MaximumProperty, value);
        }

        public double Value1
        {
            get => (double)GetValue(Value1Property);
            set => SetValue(Value1Property, value);
        }

        public double Value2
        {
            get => (double)GetValue(Value2Property);
            set => SetValue(Value2Property, value);
        }

        public string ValueDisplay
        {
            get => $"{Value1:0.##} - {Value2:0.##}";
        }

        public static readonly DependencyProperty MaximumProperty =
            DependencyProperty.Register("Maximum", typeof(double), typeof(DoubleSlider));

        public static readonly DependencyProperty MinimumProperty =
            DependencyProperty.Register("Minimum", typeof(double), typeof(DoubleSlider));

        public static readonly DependencyProperty Value1Property =
            DependencyProperty.Register("Value1", typeof(double), typeof(DoubleSlider));

        public static readonly DependencyProperty Value2Property =
            DependencyProperty.Register("Value2", typeof(double), typeof(DoubleSlider));

        private void slider1_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Slider2.Value = Math.Max(Slider2.Value, Slider1.Value);
            OnPropertyChanged(nameof(ValueDisplay));
            RefreshHighlight();
        }

        private void slider2_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            Slider1.Value = Math.Min(Slider2.Value, Slider1.Value);
            OnPropertyChanged(nameof(ValueDisplay));
            RefreshHighlight();
        }

        private void RefreshHighlight()
        {
            if(_thumbLeft == null || _thumbRight == null)
            {
                return;
            }

            // Re-position the blue highlight bar when values change
            var leftThumbPos = _thumbLeft.TranslatePoint(new Point(0, 0), this);
            var rightThumbPos = _thumbRight.TranslatePoint(new Point(0, 0), this);
            HighlightBorder.Margin = new Thickness(leftThumbPos.X + _thumbLeft.ActualWidth - 2, 5, ActualWidth - rightThumbPos.X - 2, 5);
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
