﻿using System.Windows;
using System.Windows.Controls;

namespace ABB.CommonUX.Controls
{
    public partial class MeasureBar : UserControl
    {
        public MeasureBar()
        {
            InitializeComponent();
            Loaded += MeasureBar_Loaded;
        }

        public string Label
        {
            get => (string)GetValue(LabelProperty);
            set => SetValue(LabelProperty, value);
        }

        public string Unit
        {
            get => (string)GetValue(UnitProperty);
            set => SetValue(UnitProperty, value);
        }

        public double Value
        {
            get => (double)GetValue(ValueProperty);
            set => SetValue(ValueProperty, value);
        }

        public double LowWarning
        {
            get => (double)GetValue(LowWarningProperty);
            set => SetValue(LowWarningProperty, value);
        }

        public double HighWarning
        {
            get => (double)GetValue(HighWarningProperty);
            set => SetValue(HighWarningProperty, value);
        }

        public double LowAlarm
        {
            get => (double)GetValue(LowAlarmProperty);
            set => SetValue(LowAlarmProperty, value);
        }

        public double HighAlarm
        {
            get => (double)GetValue(HighAlarmProperty);
            set => SetValue(HighAlarmProperty, value);
        }

        public double Minimum
        {
            get => (double)GetValue(MinimumProperty);
            set => SetValue(MinimumProperty, value);
        }

        public double Maximum
        {
            get => (double)GetValue(MaximumProperty);
            set => SetValue(MaximumProperty, value);
        }

        public static readonly DependencyProperty LabelProperty = DependencyProperty.Register("Label", typeof(string), typeof(MeasureBar));
        public static readonly DependencyProperty UnitProperty = DependencyProperty.Register("Unit", typeof(string), typeof(MeasureBar));

        public static readonly DependencyProperty ValueProperty = DependencyProperty.Register("Value", typeof(double), typeof(MeasureBar),
            new FrameworkPropertyMetadata(0.0, OnValuePropertyChanged));       
        public static readonly DependencyProperty LowWarningProperty = DependencyProperty.Register("LowWarning", typeof(double), typeof(MeasureBar),
            new FrameworkPropertyMetadata(0.0, OnLimitPropertyChanged));
        public static readonly DependencyProperty HighWarningProperty = DependencyProperty.Register("HighWarning", typeof(double), typeof(MeasureBar),
            new FrameworkPropertyMetadata(0.0, OnLimitPropertyChanged));
        public static readonly DependencyProperty LowAlarmProperty = DependencyProperty.Register("LowAlarm", typeof(double), typeof(MeasureBar),
            new FrameworkPropertyMetadata(0.0, OnLimitPropertyChanged));
        public static readonly DependencyProperty HighAlarmProperty = DependencyProperty.Register("HighAlarm", typeof(double), typeof(MeasureBar),
            new FrameworkPropertyMetadata(0.0, OnLimitPropertyChanged));
        public static readonly DependencyProperty MinimumProperty = DependencyProperty.Register("Minimum", typeof(double), typeof(MeasureBar),
            new FrameworkPropertyMetadata(0.0, OnLimitPropertyChanged));
        public static readonly DependencyProperty MaximumProperty = DependencyProperty.Register("Maximum", typeof(double), typeof(MeasureBar),
            new FrameworkPropertyMetadata(0.0, OnLimitPropertyChanged));

        private static void OnValuePropertyChanged(DependencyObject sender, DependencyPropertyChangedEventArgs e)
        {
            var mb = sender as MeasureBar;
            mb.OnValueChanged();            
        }

        private static void OnLimitPropertyChanged(DependencyObject sender, DependencyPropertyChangedEventArgs e)
        {
            var mb = sender as MeasureBar;
            mb.OnLimitChanged();
        }

        private void MeasureBar_Loaded(object sender, RoutedEventArgs e)
        {
            OnValueChanged();
            OnLimitChanged();
        }

        private void OnLimitChanged()
        {
            double min = Minimum;
            double max = Maximum;

            double percent = max <= min ? 1.0 : (LowAlarm - min) / (max - min);
            LowAlarmTranslate.X = percent * ProgressBar.ActualWidth;
            percent = max <= min ? 1.0 : (LowWarning - min) / (max - min);
            LowWarningTranslate.X = percent * ProgressBar.ActualWidth;
            percent = max <= min ? 1.0 : (HighAlarm - min) / (max - min);
            HighAlarmTranslate.X = percent * ProgressBar.ActualWidth;
            percent = max <= min ? 1.0 : (HighWarning - min) / (max - min);
            HighWarningTranslate.X = percent * ProgressBar.ActualWidth;
        }

        private void OnValueChanged()
        {
            if (Value <= LowAlarm)
            {
                ProgressBar.SetResourceReference(ForegroundProperty, "Abb.Alarm.Red.Brush");
            }
            else if (Value <= LowWarning)
            {
                ProgressBar.SetResourceReference(ForegroundProperty, "Abb.Alarm.Yellow.Brush");
            }
            else if(Value >= HighAlarm)
            {
                ProgressBar.SetResourceReference(ForegroundProperty, "Abb.Alarm.Red.Brush");
            }
            else if(Value >= HighWarning)
            {
                ProgressBar.SetResourceReference(ForegroundProperty, "Abb.Alarm.Yellow.Brush");
            }
            else
            {
                ProgressBar.SetResourceReference(ForegroundProperty, "Abb.Alarm.Blue.Brush");
            }
        }
    }
}
