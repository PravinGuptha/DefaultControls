﻿using System;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Interop;
using System.Windows.Media;

namespace ABB.CommonUX
{
    public class NotificationAreaPopup : Popup
    {
        private bool? _appliedTopMost;
        private readonly StackPanel _notifications;

        public static readonly DependencyProperty HostControlProperty = DependencyProperty.RegisterAttached("HostControl",
                typeof(FrameworkElement), typeof(NotificationAreaPopup), new PropertyMetadata(null, HostControlPropertyChanged));

        public FrameworkElement HostControl
        {
            get => (FrameworkElement)GetValue(HostControlProperty);
            set => SetValue(HostControlProperty, value);
        }

        public NotificationAreaPopup()
        {
            IsOpen = true;
            StaysOpen = true;
            Placement = PlacementMode.Absolute;
            IsHitTestVisible = false;
            AllowsTransparency = true;

            _notifications = new StackPanel
            {
                Orientation = Orientation.Vertical,
                Background = Brushes.Transparent
            };
            Child = _notifications;

            Notifications.NotificationArea = this;

            Loaded += OnLoaded;
        }

        public void AddNotification(UIElement notification)
        {
            _notifications.Children.Add(notification);
        }

        public void RemoveNotification(UIElement notification)
        {
            _notifications.Children.Remove(notification);
        }

        private static void HostControlPropertyChanged(DependencyObject source, DependencyPropertyChangedEventArgs e)
        {
            var popup = source as NotificationAreaPopup;
            popup?.UpdatePopupPosition();
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            var parentWindow = Window.GetWindow(this);
            if (parentWindow != null)
            {
                parentWindow.LocationChanged += delegate (object o, EventArgs args)
                {
                    UpdatePopupPosition();
                };

                parentWindow.SizeChanged += delegate (object o, SizeChangedEventArgs args)
                {
                    UpdatePopupPosition();
                };

                parentWindow.StateChanged += delegate (object o, EventArgs args)
                {
                    SetTopmostState(parentWindow.WindowState != WindowState.Minimized);
                };

                parentWindow.Activated += delegate (object o, EventArgs args)
                {
                    SetTopmostState(true);
                };

                parentWindow.Deactivated += delegate (object o, EventArgs args)
                {
                    SetTopmostState(false);
                };
            }

            UpdatePopupPosition();
        }

        private void UpdatePopupPosition()
        {
            var parentWindow = Window.GetWindow(this);
            if (parentWindow != null && PresentationSource.FromVisual(parentWindow) != null)
            {
                const int padding = 20;
                const int width = 530;

                if (HostControl != null)
                {
                    var controlPos = HostControl.PointToScreen(new Point());
                    Width = width;
                    Height = HostControl.ActualHeight - padding * 2;
                    HorizontalOffset = controlPos.X + HostControl.ActualWidth - Width - padding;
                    VerticalOffset = controlPos.Y + padding + 20;
                }
                else
                {
                    var winPos = parentWindow.PointToScreen(new Point());
                    Width = width;
                    Height = parentWindow.ActualHeight - padding * 2;
                    HorizontalOffset = winPos.X + parentWindow.ActualWidth - Width - padding;
                    VerticalOffset = winPos.Y + padding;
                }
            }
        }

        // Code below is from https://stackoverflow.com/questions/7606954/popup-always-stays-on-top
        private void SetTopmostState(bool isTop)
        {
            // Don’t apply state if it’s the same as incoming state
            if (_appliedTopMost.HasValue && _appliedTopMost == isTop)
            {
                return;
            }

            if (Child == null)
                return;

            var hwndSource = (PresentationSource.FromVisual(Child)) as HwndSource;

            if (hwndSource == null)
                return;

            var hwnd = hwndSource.Handle;

            if (!GetWindowRect(hwnd, out var rect))
                return;

            if (isTop)
            {
                SetWindowPos(hwnd, HWND_TOPMOST, rect.Left, rect.Top, (int)Width, (int)Height, TOPMOST_FLAGS);
            }
            else
            {
                // Z-Order would only get refreshed/reflected if clicking the
                // the titlebar (as opposed to other parts of the external
                // window) unless I first set the popup to HWND_BOTTOM
                // then HWND_TOP before HWND_NOTOPMOST
                SetWindowPos(hwnd, HWND_BOTTOM, rect.Left, rect.Top, (int)Width, (int)Height, TOPMOST_FLAGS);
                SetWindowPos(hwnd, HWND_TOP, rect.Left, rect.Top, (int)Width, (int)Height, TOPMOST_FLAGS);
                SetWindowPos(hwnd, HWND_NOTOPMOST, rect.Left, rect.Top, (int)Width, (int)Height, TOPMOST_FLAGS);
            }

            _appliedTopMost = isTop;
        }

        #region P/Invoke imports & definitions
#pragma warning disable 1591 //Xml-doc
#pragma warning disable 169 //Never used-warning
        // ReSharper disable InconsistentNaming
        // Imports etc. with their naming rules

        [StructLayout(LayoutKind.Sequential)]
        private struct RECT
        {
            public int Left;
            public int Top;
            public int Right;
            public int Bottom;
        }

        [DllImport("user32.dll")]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool GetWindowRect(IntPtr hWnd, out RECT lpRect);

        [DllImport("user32.dll")]
        private static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X,
        int Y, int cx, int cy, uint uFlags);

        static readonly IntPtr HWND_TOPMOST = new IntPtr(-1);
        static readonly IntPtr HWND_NOTOPMOST = new IntPtr(-2);
        static readonly IntPtr HWND_TOP = new IntPtr(0);
        static readonly IntPtr HWND_BOTTOM = new IntPtr(1);
        private const UInt32 SWP_NOSIZE = 0x0001;
        private const UInt32 SWP_NOMOVE = 0x0002;
        private const UInt32 SWP_NOREDRAW = 0x0008;
        private const UInt32 SWP_NOACTIVATE = 0x0010;
        private const UInt32 SWP_NOOWNERZORDER = 0x0200; /* Don’t do owner Z ordering */
        private const UInt32 SWP_NOSENDCHANGING = 0x0400; /* Don’t send WM_WINDOWPOSCHANGING */

        private const UInt32 TOPMOST_FLAGS = SWP_NOACTIVATE | SWP_NOOWNERZORDER | SWP_NOSIZE | SWP_NOMOVE | SWP_NOREDRAW | SWP_NOSENDCHANGING;

        // ReSharper restore InconsistentNaming
#pragma warning restore 1591
#pragma warning restore 169
        #endregion
    }
}
