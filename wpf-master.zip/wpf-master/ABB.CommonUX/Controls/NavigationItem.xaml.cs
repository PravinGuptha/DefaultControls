﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;

namespace ABB.CommonUX.Controls
{
    public partial class NavigationItem : UserControl
    {
        public NavigationItem()
        {
            InitializeComponent();
        }

        public event EventHandler Checked;

        public static readonly DependencyProperty MenuProperty =
            DependencyProperty.Register("Menu", typeof(ContextMenu), typeof(NavigationItem), new FrameworkPropertyMetadata(OnMenuPropertyChanged));

        public static readonly DependencyProperty HeaderProperty =
            DependencyProperty.Register("Header", typeof(string), typeof(NavigationItem));

        public static readonly DependencyProperty IsCheckedProperty =
            DependencyProperty.Register("IsChecked", typeof(bool), typeof(NavigationItem));

        private static void OnMenuPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            ((NavigationItem)d).OnMenuPropertyChanged();
        }

        private void OnMenuPropertyChanged()
        {
            MenuIndicator.Visibility = Menu != null ? Visibility.Visible : Visibility.Collapsed;
        }

        public ContextMenu Menu
        {
            get => (ContextMenu)GetValue(MenuProperty);
            set => SetValue(MenuProperty, value);
        }

        public string Header
        {
            get => (string)GetValue(HeaderProperty);
            set => SetValue(HeaderProperty, value);
        }

        public bool IsChecked
        {
            get => (bool)GetValue(IsCheckedProperty);
            set => SetValue(IsCheckedProperty, value);
        }

        private void NavigationButton_OnChecked(object sender, RoutedEventArgs e)
        {
            Checked?.Invoke(sender, e);
        }

        private void NavigationButton_OnPreviewMouseUp(object sender, MouseButtonEventArgs e)
        {
            // If there is a menu available, show it and prevent OnChecked.
            // User has to do his own "checking" based on menu actions.
            if (ShowMenuIfAvailable())
            {
                e.Handled = true;
            }
        }

        private void NavigationButton_OnPreviewKeyUp(object sender, KeyEventArgs e)
        {
            // If there is a menu available, show it and prevent OnChecked.
            // User has to do his own "checking" based on menu actions.
            if (e.Key == Key.Space || e.Key == Key.Enter)
            {
                if(ShowMenuIfAvailable())
                {
                    e.Handled = true;
                }
            }
        }

        private bool ShowMenuIfAvailable()
        {
            if (Menu != null)
            {
                Menu.Placement = PlacementMode.Bottom;
                Menu.PlacementTarget = this;
                Menu.IsOpen = true;
                return true;
            }

            return false;
        }
    }
}
