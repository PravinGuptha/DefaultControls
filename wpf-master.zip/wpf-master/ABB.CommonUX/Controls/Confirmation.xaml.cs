﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace ABB.CommonUX.Controls
{
    public partial class Confirmation : UserControl
    {
        public event EventHandler NotificationClose;

        public Confirmation(string message, Notifications.NotificationType type, string primaryText, string secondaryText, Action primaryAction, Action secondaryAction)
        {
            InitializeComponent();

            MessageText.Text = message;
            PrimaryButton.Content = primaryText;
            SecondaryButton.Content = secondaryText;

            PrimaryButton.Click += delegate
            {
                CloseBox();
                primaryAction(); 
            };

            SecondaryButton.Click += delegate
            {
                CloseBox();
                secondaryAction(); 
            };

            switch (type)
            {
                case Notifications.NotificationType.Information:
                    HighlightBar.SetResourceReference(Shape.FillProperty, "Notification.Info.Accent.Brush");
                    icon.SetResourceReference(ForegroundProperty, "Notification.Info.Accent.Brush");
                    icon.Image = IconType.information_circle_1_16;
                    break;
                case Notifications.NotificationType.Warning:
                    HighlightBar.SetResourceReference(Shape.FillProperty, "Notification.Warning.Accent.Brush");
                    icon.SetResourceReference(ForegroundProperty, "Notification.Warning.Accent.Brush");
                    icon.Image = IconType.warning_circle_1_16;
                    break;
                case Notifications.NotificationType.Error:
                    HighlightBar.SetResourceReference(Shape.FillProperty, "Notification.Error.Accent.Brush");
                    icon.SetResourceReference(ForegroundProperty, "Notification.Error.Accent.Brush");
                    icon.Image = IconType.error_circle_1_16;
                    break;
                case Notifications.NotificationType.Confirmation:
                    HighlightBar.SetResourceReference(Shape.FillProperty, "Notification.Confirm.Accent.Brush");
                    icon.SetResourceReference(ForegroundProperty, "Notification.Confirm.Accent.Brush");
                    icon.Image = IconType.check_mark_circle_1_16;
                    break;
                default:
                    throw new ArgumentOutOfRangeException(nameof(type), type, null);
            }
        }

        private void CloseBox()
        {
            var sb = FindResource("WindowCloseAnimation") as Storyboard;
            sb.Completed += (o, eventArgs) =>
            {
                NotificationClose?.Invoke(this, EventArgs.Empty);
            };
            sb.Begin();
        }
    }
}
