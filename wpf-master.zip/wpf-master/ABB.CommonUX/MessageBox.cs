﻿using System.Collections.Generic;
using System.Windows;

namespace ABB.CommonUX
{
    public static class MessageBox
    {
        public static MessageBoxResult Show(Window owner, string title, string message)
        {
            return Show(owner, title, message, MessageBoxButton.OK, null);
        }

        public static MessageBoxResult Show(Window owner, string title, string message, MessageBoxButton button)
        {
            return Show(owner, title, message, button, null);
        }

        public static MessageBoxResult Show(Window owner, string title, string message, MessageBoxButton button, IconType? icon)
        {
            var mb = new Windows.MessageBox(message, GetButtonConfig(button))
            {
                Owner = owner,
                WindowStartupLocation = WindowStartupLocation.CenterOwner,
                Title = title
            };

            mb.ShowDialog();
            return mb.Result;
        }

        private static List<Windows.MessageBoxButton> GetButtonConfig(MessageBoxButton button)
        {
            switch (button)
            {                
                case MessageBoxButton.OKCancel:
                    return new List<Windows.MessageBoxButton>
                    {
                        new Windows.MessageBoxButton { Text = "Cancel", IsCancel = true, Result = MessageBoxResult.Cancel },
                        new Windows.MessageBoxButton { Text = "Ok", IsDefault = true, Result = MessageBoxResult.OK }
                    };
                case MessageBoxButton.YesNoCancel:
                    return new List<Windows.MessageBoxButton>
                    {
                        new Windows.MessageBoxButton { Text = "Cancel", IsCancel = true, Result = MessageBoxResult.Cancel },
                        new Windows.MessageBoxButton { Text = "No", Result = MessageBoxResult.No },
                        new Windows.MessageBoxButton { Text = "Yes", IsDefault = true, Result = MessageBoxResult.Yes }
                    };
                case MessageBoxButton.YesNo:
                    return new List<Windows.MessageBoxButton>
                    {
                        new Windows.MessageBoxButton { Text = "No", IsCancel = true, Result = MessageBoxResult.No },
                        new Windows.MessageBoxButton { Text = "Yes", IsDefault = true, Result = MessageBoxResult.Yes }
                    };
                default:
                    return new List<Windows.MessageBoxButton>
                    {
                        new Windows.MessageBoxButton { Text = "Ok", IsDefault = true, IsCancel = true, Result = MessageBoxResult.OK }
                    };
            }
        }
    }
}
