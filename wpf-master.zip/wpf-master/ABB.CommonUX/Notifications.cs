﻿using System;
using System.Windows;
using ABB.CommonUX.Controls;
using ABB.CommonUX.Utils;

namespace ABB.CommonUX
{
    public static class Notifications
    {
        public enum NotificationType
        {
            Confirmation,
            ConfirmationDiscreet,
            Information,
            InformationDiscreet,
            Warning,
            WarningDiscreet,
            Error,
            ErrorDiscreet
        };

        internal static NotificationAreaPopup NotificationArea { get; set; }

        public static void Show(string message, NotificationType type, int timeoutMs = 5000)
        {
            if(NotificationArea == null)
            {
                throw new CommonUXException("You need to place NotificationAreaPopup control somewhere in MainWindow to display notifications."); 
            }

            var notification = new Notification(message, type, timeoutMs);
            notification.NotificationClose += delegate(object sender, EventArgs args)
            {
                NotificationArea.RemoveNotification(sender as UIElement);
            };

            NotificationArea.AddNotification(notification);            
        }

        public static void Show(string message, NotificationType type, string primaryText, string secondaryText, Action primaryAction, Action secondaryAction)
        {
            if (NotificationArea == null)
            {
                throw new CommonUXException("You need to place NotificationAreaPopup control somewhere in MainWindow to display notifications.");
            }

            var notification = new Confirmation(message, type, primaryText, secondaryText, primaryAction, secondaryAction);
            notification.NotificationClose += delegate (object sender, EventArgs args)
            {
                NotificationArea.RemoveNotification(sender as UIElement);
            };

            NotificationArea.AddNotification(notification);
        }
    }
}
