﻿using System;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Input;
using System.Windows.Interop;
// ReSharper disable All

namespace ABB.CommonUX.Utils
{
    /// <summary>
    /// Collection of P/Invokes
    /// </summary>
    internal static class WindowInterop
    {
        private const int WM_SYSCOMMAND = 0x112;
        private const uint TPM_LEFTALIGN = 0x0000;
        private const uint TPM_RETURNCMD = 0x0100;
        private const UInt32 MF_ENABLED = 0x00000000;
        private const UInt32 MF_GRAYED = 0x00000001;
        private const UInt32 SC_MAXIMIZE = 0xF030;        

        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr GetSystemMenu(IntPtr hWnd, bool bRevert);

        [DllImport("user32.dll")]
        private static extern int TrackPopupMenuEx(IntPtr hmenu, uint fuFlags, int x, int y, IntPtr hwnd, IntPtr lptpm);

        [DllImport("user32.dll")]
        private static extern IntPtr PostMessage(IntPtr hWnd, uint Msg, IntPtr wParam, IntPtr lParam);

        [DllImport("user32.dll")]
        private static extern bool EnableMenuItem(IntPtr hMenu, uint uIDEnableItem, uint uEnable);

        /// <summary>
        /// Open titlebar icon system menu.
        /// </summary>
        public static void ShowSystemMenu(MouseButtonEventArgs e)
        {
            if (Application.Current.MainWindow != null)
            {
                var helper = new WindowInteropHelper(Application.Current.MainWindow);
                var hMenu = GetSystemMenu(helper.Handle, false);

                if (Application.Current.MainWindow.WindowState == WindowState.Maximized)
                {
                    EnableMenuItem(hMenu, SC_MAXIMIZE, MF_GRAYED);
                }
                else
                {
                    EnableMenuItem(hMenu, SC_MAXIMIZE, MF_ENABLED);
                }

                // Open menu on cursor position.

                var windowPosition = Application.Current.MainWindow.PointToScreen(e.GetPosition(Application.Current.MainWindow));
                windowPosition.Offset(16, 16);

                var command = TrackPopupMenuEx(hMenu, TPM_LEFTALIGN | TPM_RETURNCMD, (int)windowPosition.X, (int)windowPosition.Y, helper.Handle, IntPtr.Zero);
                if (command == 0)
                    return;

                PostMessage(helper.Handle, WM_SYSCOMMAND, new IntPtr(command), IntPtr.Zero);
            }
        }
    }
}
