﻿using System.Windows;
using System.Windows.Controls;

namespace ABB.CommonUX
{
    public class ModalDialog : Window
    {
        static ModalDialog()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(ModalDialog), new FrameworkPropertyMetadata(typeof(ModalDialog)));
        }

        protected ModalDialog()
        {
            Loaded += ModalDialog_Loaded;
        }

        private void ModalDialog_Loaded(object sender, RoutedEventArgs e)
        {
            if (Template.FindName("dragPanel", this) is Panel panel)
            {
                panel.MouseDown += delegate { DragMove(); };
            }

            if (Template.FindName("closeButton", this) is Button button)
            {
                button.Click += delegate
                {
                    DialogResult = false;
                    Close();
                };
            }
        }
    }
}
