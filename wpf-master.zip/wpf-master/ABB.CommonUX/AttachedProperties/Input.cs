﻿using System.Windows;
using System.Windows.Controls;
// ReSharper disable CheckNamespace

namespace ABB.CommonUX
{
    public static class Input
    {
        public static readonly DependencyProperty LabelProperty
            = DependencyProperty.RegisterAttached("Label", typeof(string), typeof(Input), new PropertyMetadata(null));

        public static readonly DependencyProperty DescriptionProperty
            = DependencyProperty.RegisterAttached("Description", typeof(string), typeof(Input), new PropertyMetadata(null));

        public static readonly DependencyProperty PlaceholderProperty
            = DependencyProperty.RegisterAttached("Placeholder", typeof(string), typeof(Input), new PropertyMetadata(null));

        public static readonly DependencyProperty ImageProperty
            = DependencyProperty.RegisterAttached("Image", typeof(IconType?), typeof(Input), new PropertyMetadata(null));

        [AttachedPropertyBrowsableForType(typeof(TextBox))]
        [AttachedPropertyBrowsableForType(typeof(PasswordBox))]
        public static void SetLabel(DependencyObject obj, string value)
        {
            obj.SetValue(LabelProperty, value);
        }

        [AttachedPropertyBrowsableForType(typeof(TextBox))]
        [AttachedPropertyBrowsableForType(typeof(PasswordBox))]
        public static string GetLabel(DependencyObject obj)
        {
            return (string)obj.GetValue(LabelProperty);
        }

        [AttachedPropertyBrowsableForType(typeof(TextBox))]
        [AttachedPropertyBrowsableForType(typeof(PasswordBox))]
        public static void SetDescription(DependencyObject obj, string value)
        {
            obj.SetValue(DescriptionProperty, value);
        }

        [AttachedPropertyBrowsableForType(typeof(TextBox))]
        [AttachedPropertyBrowsableForType(typeof(PasswordBox))]
        public static string GetDescription(DependencyObject obj)
        {
            return (string)obj.GetValue(DescriptionProperty);
        }

        [AttachedPropertyBrowsableForType(typeof(TextBox))]
        [AttachedPropertyBrowsableForType(typeof(PasswordBox))]
        public static void SetPlaceholder(DependencyObject obj, string value)
        {
            obj.SetValue(PlaceholderProperty, value);
        }

        [AttachedPropertyBrowsableForType(typeof(TextBox))]
        [AttachedPropertyBrowsableForType(typeof(PasswordBox))]
        public static string GetPlaceholder(DependencyObject obj)
        {
            return (string)obj.GetValue(PlaceholderProperty);
        }

        [AttachedPropertyBrowsableForType(typeof(TextBox))]        
        public static void SetImage(DependencyObject obj, IconType? value)
        {
            obj.SetValue(ImageProperty, value);
        }

        [AttachedPropertyBrowsableForType(typeof(TextBox))]
        public static IconType? GetImage(DependencyObject obj)
        {
            return (IconType)obj.GetValue(ImageProperty);
        }
    }
}
