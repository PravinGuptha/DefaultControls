﻿using System;
using System.Windows;
using System.Windows.Controls;
using ABB.CommonUX.Controls;

namespace ABB.CommonUX.TestApp
{
    /// <summary>
    /// Interaction logic for IconBrowser.xaml
    /// </summary>
    public partial class IconBrowser : UserControl
    {
        public IconBrowser()
        {
            InitializeComponent();

            foreach (IconType icon in Enum.GetValues(typeof(IconType)))
            {
                var panel = new StackPanel {Orientation = Orientation.Vertical, Margin = new Thickness(8), MinWidth = 100, MaxWidth = 100};

                var text = new TextBlock {Text = icon.ToString(), HorizontalAlignment = HorizontalAlignment.Center};

                var i = new Icon
                {
                    Image = icon, HorizontalAlignment = HorizontalAlignment.Center, Margin = new Thickness(4)
                };
                i.SetResourceReference(Icon.StyleProperty, "IconLarge");

                panel.Children.Add(i);
                panel.Children.Add(text);

                iconWrap.Children.Add(panel);
            }
        }
    }
}
