﻿using System;
using System.Runtime.Serialization;
using System.Security.Permissions;

namespace ABB.CommonUX.Utils
{
    [Serializable]
    public class CommonUXException : Exception
    {
        public string ResourceReferenceProperty { get; set; }

        public CommonUXException()
        {
        }

        public CommonUXException(string message)
            : base(message)
        {
        }

        public CommonUXException(string message, Exception inner)
            : base(message, inner)
        {
        }

        protected CommonUXException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        {
            ResourceReferenceProperty = info.GetString("ResourceReferenceProperty");
        }

        [SecurityPermission(SecurityAction.Demand, SerializationFormatter = true)]
        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            if (info == null)
                throw new ArgumentNullException("info");
            info.AddValue("ResourceReferenceProperty", ResourceReferenceProperty);
            base.GetObjectData(info, context);
        }
    }
}
