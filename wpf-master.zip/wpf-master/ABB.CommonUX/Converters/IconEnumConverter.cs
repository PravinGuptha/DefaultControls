﻿using ABB.CommonUX.Generated;
using System;
using System.Globalization;
using System.Linq;
using System.Windows;
using System.Windows.Data;

namespace ABB.CommonUX.Converters
{
    public class IconEnumConverter : IMultiValueConverter
    {
        public object Convert(object[] values, Type targetType, object parameter, CultureInfo culture)
        {
            var element = values.OfType<FrameworkElement>().FirstOrDefault();
            var type = values.OfType<IconType?>().FirstOrDefault();

            if (element != null && type.HasValue && IconMapping.Mappings.TryGetValue(type.Value, out var mapping))
                return element.TryFindResource(mapping) ?? DependencyProperty.UnsetValue;
            else
                return DependencyProperty.UnsetValue;
        }

        public object[] ConvertBack(object value, Type[] targetTypes, object parameter, CultureInfo culture)
        {
            return Enumerable.Repeat(DependencyProperty.UnsetValue, targetTypes.Length).ToArray();
        }
    }
}
