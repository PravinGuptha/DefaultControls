﻿using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using ABB.CommonUX.Windows;
using MessageBoxButton = System.Windows.MessageBoxButton;

namespace ABB.CommonUX.TestApp
{
    /// <inheritdoc cref="UserControl" />
    /// <summary>
    /// Interaction logic for Popups.xaml
    /// </summary>
    public partial class Popups : UserControl
    {
        private const string ExampleText = "Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.";

        public Popups()
        {
            InitializeComponent();
        }

        private void ButtonBase_OnClick(object sender, RoutedEventArgs e)
        {
            var dialog = new TestModal { Owner = App.Current.MainWindow, WindowStartupLocation = WindowStartupLocation.CenterOwner };
            dialog.ShowDialog();
        }

        private void MessageBox1_Click(object sender, RoutedEventArgs e)
        {
            MessageResult.Text = MessageBox.Show(App.Current.MainWindow, "Hello World", ExampleText).ToString();
        }

        private void MessageBox2_Click(object sender, RoutedEventArgs e)
        {
            MessageResult.Text = MessageBox.Show(App.Current.MainWindow, "Hello World?", ExampleText, MessageBoxButton.OKCancel).ToString();
        }

        private void MessageBox3_Click(object sender, RoutedEventArgs e)
        {
            MessageResult.Text = MessageBox.Show(App.Current.MainWindow, "Hello World?", ExampleText, MessageBoxButton.YesNo).ToString();
        }

        private void MessageBox4_Click(object sender, RoutedEventArgs e)
        {
            MessageResult.Text = MessageBox.Show(App.Current.MainWindow, "Hello World?", ExampleText, MessageBoxButton.YesNoCancel).ToString();
        }

        private void ErrorBanner_Click(object sender, RoutedEventArgs e)
        {
            Notifications.Show("Error hello world notification", Notifications.NotificationType.Error);
        }

        private void WarningBanner_Click(object sender, RoutedEventArgs e)
        {
            Notifications.Show("Warning hello world notification", Notifications.NotificationType.Warning);
        }

        private void InfoBanner_Click(object sender, RoutedEventArgs e)
        {
            Notifications.Show("Info hello world notification", Notifications.NotificationType.Information);
        }

        private void ConfirmBanner_Click(object sender, RoutedEventArgs e)
        {
            Notifications.Show("Confirmation notification", Notifications.NotificationType.Confirmation);
        }

        private void ErrorBannerDisc_Click(object sender, RoutedEventArgs e)
        {
            Notifications.Show("Error hello world notification", Notifications.NotificationType.ErrorDiscreet);
        }

        private void ConfirmBannerDisc_Click(object sender, RoutedEventArgs e)
        {
            Notifications.Show("Confirmation notification", Notifications.NotificationType.ConfirmationDiscreet);
        }

        private void WarningBannerDisc_Click(object sender, RoutedEventArgs e)
        {
            Notifications.Show("Warning hello world notification", Notifications.NotificationType.WarningDiscreet);
        }

        private void InfoBannerDisc_Click(object sender, RoutedEventArgs e)
        {
            Notifications.Show("Info hello world notification", Notifications.NotificationType.InformationDiscreet);
        }

        private void Login_OnClick(object sender, RoutedEventArgs e)
        {
            var ld = new LoginDialog { Owner = Application.Current.MainWindow, WindowStartupLocation = WindowStartupLocation.CenterOwner, ProductName = "SAMPLE PRODUCT" };
            ld.ShowDialog();
        }

        private async void Splash_OnClick(object sender, RoutedEventArgs e)
        {
            var sp = new Splash { Owner = App.Current.MainWindow, ProductName = "SAMPLE PRODUCT" };
            sp.Show();

            await Task.Run(() =>
            {
                for (var i = 0; i < 100; i += 5)
                {
                    var i1 = i;
                    Dispatcher.BeginInvoke((Action)(() =>
                    {
                        sp.SetProgress(i1);
                    }));
                    Thread.Sleep(100);
                }
            });

            sp.Close();
        }

        private void ErrorConfirm_Click(object sender, RoutedEventArgs e)
        {
            Notifications.Show(ExampleText, Notifications.NotificationType.Error, "Ok", "Cancel",
                () =>
                    {
                        MessageBox.Show(Application.Current.MainWindow, "Hello World?", "Primary clicked", MessageBoxButton.OK);
                    },
                () =>
                    {
                        MessageBox.Show(Application.Current.MainWindow, "Hello World?", "Secondary clicked", MessageBoxButton.OK);
                    });
        }

        private void ConfirmConfirm_Click(object sender, RoutedEventArgs e)
        {
            Notifications.Show(ExampleText, Notifications.NotificationType.Confirmation, "Ok", "Cancel",
                () =>
                {
                    MessageBox.Show(Application.Current.MainWindow, "Hello World?", "Primary clicked", MessageBoxButton.OK);
                },
                () =>
                {
                    MessageBox.Show(Application.Current.MainWindow, "Hello World?", "Secondary clicked", MessageBoxButton.OK);
                });
        }

        private void WarningConfirm_Click(object sender, RoutedEventArgs e)
        {
            Notifications.Show(ExampleText, Notifications.NotificationType.Warning, "Ok", "Cancel",
                () =>
                {
                    MessageBox.Show(Application.Current.MainWindow, "Hello World?", "Primary clicked", MessageBoxButton.OK);
                },
                () =>
                {
                    MessageBox.Show(Application.Current.MainWindow, "Hello World?", "Secondary clicked", MessageBoxButton.OK);
                });
        }

        private void InfoConfirm_Click(object sender, RoutedEventArgs e)
        {
            Notifications.Show(ExampleText, Notifications.NotificationType.Information, "Ok", "Cancel",
                () =>
                {
                    MessageBox.Show(Application.Current.MainWindow, "Hello World?", "Primary clicked", MessageBoxButton.OK);
                },
                () =>
                {
                    MessageBox.Show(Application.Current.MainWindow, "Hello World?", "Secondary clicked", MessageBoxButton.OK);
                });
        }

        private void About_OnClick(object sender, RoutedEventArgs e)
        {
            var ld = new AboutDialog { Owner = Application.Current.MainWindow, WindowStartupLocation = WindowStartupLocation.CenterOwner };
            ld.ShowDialog();
        }
    }
}
