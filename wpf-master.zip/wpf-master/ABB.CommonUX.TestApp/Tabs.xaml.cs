﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace ABB.CommonUX.TestApp
{
    /// <summary>
    /// Interaction logic for Tabs.xaml
    /// </summary>
    public partial class Tabs : UserControl
    {
        public Tabs()
        {
            InitializeComponent();
        }

        private void CloseClicked(object sender, RoutedEventArgs e)
        {
            var button = (FrameworkElement)sender;
            var wnd = (MainWindow)button.DataContext;
            wnd.TabItemData.Remove(((FrameworkElement)e.OriginalSource).DataContext as TabItem);
        }

        private void AddTabClicked(object sender, RoutedEventArgs e)
        {
            var tabs = (FrameworkElement)sender;
            var wnd = (MainWindow)tabs.DataContext;
            wnd.TabItemData.Add(new TabItem { Text = "NewTab" });
        }
    }
}
