﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace ABB.CommonUX.Generators
{
    class Program
    {
        static void IconGenerator()
        {
            const string iconSvgRoot = @"resources\icon-sources\";// 24.svg";
            var enums = new List<Tuple<string, string>>();
            var icons = new List<Tuple<string, string>>();
            string[] sizes = { "16", "24", "32" };
            foreach (var size in sizes)
            {
                var iconSvg = $"{iconSvgRoot}{size}.svg";
                var codeProvider = new Microsoft.CSharp.CSharpCodeProvider();

                if (!File.Exists(iconSvg))
                {
                    Console.WriteLine("Couldn't open icon files. Try changing working dir to solution root.");
                    return;
                }

                var doc = XDocument.Load(iconSvg);
                foreach (var e in doc.Descendants().Where(p => p.Name.LocalName == "glyph"))
                {
                    if (e.Attribute("glyph-name") == null)
                    {
                        continue;
                    }

                    var glyphName = e.Attribute("glyph-name").Value;
                    var glyphPrefixedName = "icon_" + glyphName;

                    var glyphVariableName = e.Attribute("glyph-name")?.Value.Replace("abb_", "").Replace("-", "_");

                    // Some icons have reserved c# keywords (object, event..). Change them a bit.
                    if (!codeProvider.IsValidIdentifier(glyphVariableName))
                    {
                        glyphVariableName = "@" + glyphVariableName;
                    }

                    enums.Add(new Tuple<string, string>(glyphVariableName, glyphPrefixedName));
                    icons.Add(new Tuple<string, string>(glyphPrefixedName, e.Attribute("d")?.Value));
                }
            }

            // Build a icon ResourceDictionary file.
            var str = new StringBuilder();
            str.AppendLine("<ResourceDictionary xmlns=\"http://schemas.microsoft.com/winfx/2006/xaml/presentation\" xmlns:x=\"http://schemas.microsoft.com/winfx/2006/xaml\">");
            AddGenerationNotificationText(str);
            foreach (var i in icons)
            {
                // Add Transform (scale y -1) to flip icon around. xaml and svg seem to use different coordinate systems.
                str.AppendFormat("\t<PathGeometry x:Key=\"{0}\" Transform=\"1,0,0,-1,0,1\" Figures=\"{1}\"/>" + Environment.NewLine, i.Item1, i.Item2);
            }
            str.AppendLine("</ResourceDictionary>");
            File.WriteAllText("ABB.CommonUX/Generated/IconPaths.xaml", str.ToString());

            // Build enumerations c# class for icons.
            str = new StringBuilder();
            str.AppendLine("// ReSharper disable CheckNamespace");
            str.AppendLine("// ReSharper disable InconsistentNaming");
            str.AppendLine("// ");
            str.AppendLine("// This is generated code, don't touch it. Run ABB.CommonUX.Generators to build it.");
            str.AppendLine("//");
            str.AppendLine("namespace ABB.CommonUX\r\n{");
            str.AppendLine("\tpublic enum IconType\r\n\t{");
            foreach (var i in enums)
            {
                str.AppendFormat("\t\t{0}," + Environment.NewLine, i.Item1);
            }
            str.AppendLine("\t}\r\n}");
            File.WriteAllText("ABB.CommonUX/Generated/Icons.cs", str.ToString());

            // Build mappings from enum to path name
            str = new StringBuilder();
            str.Append("using System.Collections.Generic;\r\n");
            str.AppendLine("// ");
            str.AppendLine("// This is generated code, don't touch it. Run ABB.CommonUX.Generators to build it.");
            str.AppendLine("//");
            str.Append("namespace ABB.CommonUX.Generated\r\n{\r\n\tinternal static class IconMapping\r\n\t{\r\n");            
            str.Append("\t\tpublic static readonly Dictionary<IconType, string> Mappings = new Dictionary<IconType, string>\r\n\t\t{\r\n");
            foreach (var i in enums)
            {
                str.AppendFormat("\t\t\t{{ IconType.{0}, \"{1}\" }}, \r\n", i.Item1, i.Item2);
            }
            str.Append("\t\t};\r\n");
            str.Append("\t}\r\n}\r\n");
            File.WriteAllText("ABB.CommonUX/Generated/IconMappings.cs", str.ToString());
        }

        class Color
        {
            public string Name { get; set; }
            public string WpfName { get; set; }
            public string Light { get; set; }
            public string Dark { get; set; }
        }

        static void ColorGenerator()
        {
            if (!File.Exists("Colors.csv"))
            {
                Console.WriteLine("Couldn't open color file. Try changing working dir to solution root.");
                return;
            }
            var colors = new List<Color>();
            var lines = ReadAllLines("Colors.csv");
            foreach (var line in lines.Skip(1))
            {
                var items = line.Split(',');
                if(items.Length != 3 || string.IsNullOrEmpty(items[0]))
                {
                    continue;
                }

                var color = new Color
                {
                    Name = items[0].Trim(),
                    WpfName = BuildColorKey(items[0]),
                    Light = items[1].Trim(),
                    Dark = items[2].Trim()
                };

                // Handle references
                if(color.Light.Contains("&"))
                {
                    var k = colors.FirstOrDefault(c => c.Name == color.Light.Replace("&", ""));
                    color.Light = k?.Light;
                }
                if (color.Dark.Contains("&"))
                {
                    var k = colors.FirstOrDefault(c => c.Name == color.Dark.Replace("&", ""));
                    color.Dark = k?.Dark;
                }

                colors.Add(color);
            }

            // Build a color ResourceDictionary file (uses light theme colors as default).
            var str = new StringBuilder();
            str.AppendLine("<ResourceDictionary xmlns=\"http://schemas.microsoft.com/winfx/2006/xaml/presentation\" xmlns:x=\"http://schemas.microsoft.com/winfx/2006/xaml\"");
            str.AppendLine("xmlns:options=\"http://schemas.microsoft.com/winfx/2006/xaml/presentation/options\" xmlns:mc=\"http://schemas.openxmlformats.org/markup-compatibility/2006\"");
            str.AppendLine("mc:Ignorable=\"options\">");
            AddGenerationNotificationText(str);

            foreach (var i in colors)
            {
                str.AppendFormat("\t<Color x:Key=\"{0}\">{1}</Color>\r\n", i.WpfName, i.Light);
            }

            str.AppendLine();

            foreach (var i in colors)
            {
                str.AppendFormat("\t<SolidColorBrush x:Key=\"{0}.Brush\" Color=\"{{StaticResource {0}}}\" options:Freeze=\"True\"/>\r\n", i.WpfName);                    
            }

            str.AppendLine("</ResourceDictionary>");
            File.WriteAllText("ABB.CommonUX/Generated/Colors.xaml", str.ToString());

            // Build a Light theme
            str = new StringBuilder();
            str.AppendLine("<ResourceDictionary xmlns=\"http://schemas.microsoft.com/winfx/2006/xaml/presentation\" xmlns:x=\"http://schemas.microsoft.com/winfx/2006/xaml\"");
            str.AppendLine("xmlns:options=\"http://schemas.microsoft.com/winfx/2006/xaml/presentation/options\" xmlns:mc=\"http://schemas.openxmlformats.org/markup-compatibility/2006\"");
            str.AppendLine("mc:Ignorable=\"options\">");
            AddGenerationNotificationText(str);

            foreach (var i in colors)
            {
                str.AppendFormat("\t<Color x:Key=\"{0}\">{1}</Color>\r\n", i.WpfName, i.Light);
            }

            str.AppendLine();

            foreach (var i in colors)
            {
                str.AppendFormat("\t<SolidColorBrush x:Key=\"{0}.Brush\" Color=\"{{StaticResource {0}}}\" options:Freeze=\"True\"/>\r\n", i.WpfName);
            }

            str.AppendLine("</ResourceDictionary>");
            File.WriteAllText("ABB.CommonUX/Themes/Light.xaml", str.ToString());

            // Build a Dark theme
            str = new StringBuilder();
            str.AppendLine("<ResourceDictionary xmlns=\"http://schemas.microsoft.com/winfx/2006/xaml/presentation\" xmlns:x=\"http://schemas.microsoft.com/winfx/2006/xaml\"");
            str.AppendLine("xmlns:options=\"http://schemas.microsoft.com/winfx/2006/xaml/presentation/options\" xmlns:mc=\"http://schemas.openxmlformats.org/markup-compatibility/2006\"");
            str.AppendLine("mc:Ignorable=\"options\">");
            AddGenerationNotificationText(str);

            foreach (var i in colors)
            {
                str.AppendFormat("\t<Color x:Key=\"{0}\">{1}</Color>\r\n", i.WpfName, i.Dark);
            }

            str.AppendLine();

            foreach (var i in colors)
            {
                str.AppendFormat("\t<SolidColorBrush x:Key=\"{0}.Brush\" Color=\"{{StaticResource {0}}}\" options:Freeze=\"True\"/>\r\n", i.WpfName);
            }

            str.AppendLine("</ResourceDictionary>");
            File.WriteAllText("ABB.CommonUX/Themes/Dark.xaml", str.ToString());
        }

        private static void AddGenerationNotificationText(StringBuilder str)
        {
            str.AppendLine();
            str.AppendLine("\t<!-- This is generated code, don't touch it. Run ABB.CommonUX.Generators to build it. -->");
            str.AppendLine();
        }

        private static string BuildColorKey(string name)
        {
            var key = name.Trim();            
            var tokens = key.Split('-');
            for(int i=0; i<tokens.Length; i++)
            {
                tokens[i] = tokens[i].First().ToString().ToUpper() + tokens[i].Substring(1);
            }

            return string.Join(".", tokens);
        }

        private static string[] ReadAllLines(string file)
        {
            using (var csv = new FileStream(file, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                using (var sr = new StreamReader(csv))
                {
                    var lines = new List<string>();
                    while (!sr.EndOfStream)
                    {
                        lines.Add(sr.ReadLine());
                    }

                    return lines.ToArray();
                }
            }
        }

        static void Main(string[] args)
        {
            IconGenerator();
            ColorGenerator();
        }
    }
}
