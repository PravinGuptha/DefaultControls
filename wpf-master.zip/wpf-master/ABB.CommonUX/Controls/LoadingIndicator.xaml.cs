﻿using System.Windows.Controls;

namespace ABB.CommonUX.Controls
{
    public partial class LoadingIndicator : UserControl
    {
        public LoadingIndicator()
        {
            InitializeComponent();
        }
    }
}
