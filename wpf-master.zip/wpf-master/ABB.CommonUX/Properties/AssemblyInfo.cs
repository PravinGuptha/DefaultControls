﻿using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows;

[assembly: AssemblyTitle("ABB CommonUX WPF")]
[assembly: AssemblyDescription("CommonUX styles and themes for WPF projects")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("ABB")]
[assembly: AssemblyProduct("ABB.CommonUX")]
[assembly: AssemblyCopyright("Copyright ©  2018")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: Guid("1F11CD77-E43A-4664-8B53-9CB9DB62CDE0")]

[assembly: ComVisible(false)]

[assembly: ThemeInfo(ResourceDictionaryLocation.None, ResourceDictionaryLocation.SourceAssembly)]
