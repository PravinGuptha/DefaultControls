﻿using System;
using System.Collections.ObjectModel;
using System.Windows;
using ABB.CommonUX.Controls;

namespace ABB.CommonUX.TestApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public int? Value1 { get; set; } = null;
        public ObservableCollection<DataGridItem> DataGridData { get; set; }
        public ObservableCollection<ListViewItem> ListViewData { get; set; }
        public ObservableCollection<ComboItem> ComboBoxData { get; set; }
        public ObservableCollection<TreeItem> TreeItems { get; set; }
        public ObservableCollection<TabItem> TabItemData { get; set; }
        public ObservableCollection<Tag> TagData { get; set; }
        public ObservableCollection<Tag> TagData2 { get; set; }
        public ObservableCollection<Tag> EditTagData { get; set; }
        public ObservableCollection<Tag> EditTagsSelected { get; set; }

        private string _newTag;
        public string NewTag
        {
            get => _newTag;
            set
            {
                if (_newTag != value)
                {
                    _newTag = value;
                    if (!string.IsNullOrEmpty(_newTag))
                    {
                        var tag = new Tag { Text = value };
                        EditTagsSelected.Add(tag);
                    }
                }
            }
        }

        public MainWindow()
        {
            DataGridData = new ObservableCollection<DataGridItem>
            {
                new DataGridItem { Count = 3, Price = 1100, Item = "Item name 1" },
                new DataGridItem { Count = 4, Price = 3100, Item = "Item name 2" },
                new DataGridItem { Count = 5, Price = 4100, Item = "Item name 3" },
                new DataGridItem { Count = 6, Price = 6100, Item = "Item name 4" },
                new DataGridItem { Count = 7, Price = 1100, Item = "Item name 5" },
                new DataGridItem { Count = 8, Price = 4100, Item = "Item name 6" },
                new DataGridItem { Count = 9, Price = 3100, Item = "Item name 7" }
            };

            ListViewData = new ObservableCollection<ListViewItem>();
            for (var i = 0; i < 10000; i++)
            {
                ListViewData.Add(new ListViewItem
                {
                    Time = DateTime.Now.AddSeconds(i),
                    Text = Guid.NewGuid().ToString(),
                    Something = i % 4 == 0
                });
            }

            ComboBoxData = new ObservableCollection<ComboItem>
            {
                new ComboItem { Text = "Combobox item 1", CanSelect = true, Group = "Group 1" },
                new ComboItem { Text = "Combobox item 2", CanSelect = true, Group = "Group 1" },
                new ComboItem { Text = "Combobox item 3", CanSelect = false, Group = "Group 2" },
                new ComboItem { Text = "Combobox item 4", CanSelect = true, Group = "Group 2" }
            };

            TagData = new ObservableCollection<Tag>();
            TagData2 = new ObservableCollection<Tag>();
            EditTagData = new ObservableCollection<Tag>();
            EditTagsSelected = new ObservableCollection<Tag>();
            for (var i=0; i<20;i++)
            {
                TagData.Add(new Tag { Text = "Tag" + i });
                TagData2.Add(new Tag { Text = "Tag-Tag" + i });
                EditTagData.Add(new Tag { Text = "Tag" + i });
            }

            TreeItems = new ObservableCollection<TreeItem>
            {
                new TreeItem {Header = "Demo Tree Item 1", Icon = IconType.calendar_16},
                new TreeItem {Header = "Demo Tree Item 2", Icon = IconType.calendar_16},
                new TreeItem {Header = "Demo Tree Item 3", Icon = IconType.calendar_16},
                new TreeItem
                {
                    Header = "Demo Tree Item 4",
                    Alarming = true,
                    Icon = IconType.folder_16,
                    TreeItems = new ObservableCollection<TreeItem>
                    {
                        new TreeItem {Header = "Demo Sub Item 5", Icon = IconType.calendar_16},
                        new TreeItem
                        {
                            Header = "Demo Sub Item 6", Alarming = true, Icon = IconType.alarm_bell_16
                        },
                        new TreeItem
                        {
                            Header = "Demo Sub Item 7",
                            Icon = IconType.calendar_16,
                            TreeItems = new ObservableCollection<TreeItem>
                            {
                                new TreeItem
                                {
                                    Header = "Demo Sub Item 8", Icon = IconType.calendar_16
                                },
                                new TreeItem
                                {
                                    Header = "Demo Sub Item 9", Icon = IconType.calendar_16
                                }
                            }
                        }
                    }
                },
                new TreeItem {Header = "Demo Tree Item 5", Icon = IconType.calendar_16},
                new TreeItem {Header = "Demo Tree Item 6", Icon = IconType.calendar_16}
            };

            TabItemData = new ObservableCollection<TabItem>
            {
                new TabItem { Text = "Tab1", IsEnabled = true },
                new TabItem { Text = "Tab2", IsEnabled = false },
                new TabItem { Text = "Tab3", IsEnabled = true }
            };

            InitializeComponent();

            var naviButtons = new NavigationItem() { Header = "Buttons", IsChecked = true};
            naviButtons.Checked += (sender, args) =>
            {
                MainContent.Children.RemoveAt(0);
                MainContent.Children.Add(new Buttons());
            };
            var naviInputs = new NavigationItem() { Header = "Inputs" };
            naviInputs.Checked += (sender, args) =>
            {
                MainContent.Children.RemoveAt(0);
                MainContent.Children.Add(new Inputs());
            };
            var naviDropDown = new NavigationItem() { Header = "DropDown" };
            naviDropDown.Checked += (sender, args) =>
            {
                MainContent.Children.RemoveAt(0);
                MainContent.Children.Add(new DropDowns());
            };
            var naviPopups = new NavigationItem() { Header = "Popups" };
            naviPopups.Checked += (sender, args) =>
            {
                MainContent.Children.RemoveAt(0);
                MainContent.Children.Add(new Popups());
            };
            var naviMisc = new NavigationItem() { Header = "Misc" };
            naviMisc.Checked += (sender, args) =>
            {
                MainContent.Children.RemoveAt(0);
                MainContent.Children.Add(new Misc());
            };
            var naviDataGrid = new NavigationItem() { Header = "DataGrid" };
            naviDataGrid.Checked += (sender, args) =>
            {
                MainContent.Children.RemoveAt(0);
                MainContent.Children.Add(new DataGrids());
            };
            var naviLists = new NavigationItem() { Header = "Lists" };
            naviLists.Checked += (sender, args) =>
            {
                MainContent.Children.RemoveAt(0);
                MainContent.Children.Add(new Lists());
            };
            var naviTree = new NavigationItem() { Header = "Tree" };
            naviTree.Checked += (sender, args) =>
            {
                MainContent.Children.RemoveAt(0);
                MainContent.Children.Add(new Trees());
            };
            var naviTabs = new NavigationItem() { Header = "Tabs" };
            naviTabs.Checked += (sender, args) =>
            {
                MainContent.Children.RemoveAt(0);
                MainContent.Children.Add(new Tabs());
            };
            var naviIcons = new NavigationItem() { Header = "Icons" };
            naviIcons.Checked += (sender, args) =>
            {
                MainContent.Children.RemoveAt(0);
                MainContent.Children.Add(new IconBrowser());
            };
            Navigation.Children.Add(naviButtons);
            Navigation.Children.Add(naviInputs);            
            Navigation.Children.Add(naviDropDown);
            Navigation.Children.Add(naviPopups);
            Navigation.Children.Add(naviMisc);
            Navigation.Children.Add(naviDataGrid);
            Navigation.Children.Add(naviLists);
            Navigation.Children.Add(naviTree);
            Navigation.Children.Add(naviTabs);
            Navigation.Children.Add(naviIcons);

            MainContent.Children.Add(new Buttons());

            DataContext = this;

            StateChanged += MainWindow_StateChanged;
        }

        private void MainWindow_StateChanged(object sender, EventArgs e)
        {
            // hack from https://stackoverflow.com/questions/39578992/wpf-borderless-window-not-maximizing-correctly
            MainGrid.Margin = WindowState == WindowState.Maximized ? new Thickness(6) : new Thickness(0);
        }

        private void OnThemeClick(object sender, RoutedEventArgs e)
        {
            IsEnabled = false;
            Themes.ChangeTheme(Application.Current,
                Themes.GetCurrentTheme(Application.Current) == Themes.Theme.Light ? Themes.Theme.Dark : Themes.Theme.Light);

            IsEnabled = true;
        }
    }

    public class DataGridItem
    {
        public int Count { get; set; }
        public int Price { get; set; }
        public string Item { get; set; }
    }

    public class ListViewItem
    {
        public DateTime Time { get; set; }
        public string Text { get; set; }
        public bool Something { get; set; }
    }

    public class ComboItem
    {
        public string Text { get; set; }
        public string Group { get; set; }
        public bool CanSelect { get; set; }
    }

    public class TreeItem
    {
        public string Header { get; set; }
        public ObservableCollection<TreeItem> TreeItems { get; set; }
        public bool Alarming { get; set; }
        public IconType Icon { get; set; }
    }

    public class Tag
    {
        public string Text { get; set; }
        public override string ToString()
        {
            return Text;
        }
    }

    public class TabItem
    {
        public string Text { get; set; }
        public bool IsEnabled { get; set; }
    }
}
