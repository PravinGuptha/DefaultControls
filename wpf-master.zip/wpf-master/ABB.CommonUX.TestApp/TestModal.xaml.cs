﻿using System.Windows;

namespace ABB.CommonUX.TestApp
{
    /// <summary>
    /// Interaction logic for TestModal.xaml
    /// </summary>
    public partial class TestModal : ModalDialog
    {
        public TestModal()
        {
            InitializeComponent();
        }

        private void Ok_OnClick(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
            Close();
        }
    }
}
