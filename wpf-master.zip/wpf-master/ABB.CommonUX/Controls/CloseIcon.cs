﻿using System.Windows;
using System.Windows.Controls;

namespace ABB.CommonUX.Controls
{
    public class CloseIconSmall : Button {
        static CloseIconSmall()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(CloseIconSmall), new FrameworkPropertyMetadata(typeof(CloseIconSmall)));
        }
    }
    public class CloseIconMedium : Button
    {
        static CloseIconMedium()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(CloseIconMedium), new FrameworkPropertyMetadata(typeof(CloseIconMedium)));
        }
    }
    public class CloseIconLarge : Button
    {
        static CloseIconLarge()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(CloseIconLarge), new FrameworkPropertyMetadata(typeof(CloseIconLarge)));
        }
    }
}
