﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace ABB.CommonUX.Controls
{
    public partial class TopBar : UserControl
    {
        public TopBar()
        {
            InitializeComponent();
            DataContext = this;
            MouseDown += (target, e) =>
            {
                if (e.LeftButton == MouseButtonState.Pressed && e.RightButton != MouseButtonState.Pressed)
                {
                    if (ShowWindowControls && Application.Current.MainWindow != null)
                    {
                        Application.Current.MainWindow.DragMove();
                    }
                }
            };

            MouseDoubleClick += delegate
            {
                if (ShowWindowControls && Application.Current.MainWindow != null)
                {
                    Application.Current.MainWindow.WindowState = Application.Current.MainWindow.WindowState == WindowState.Maximized ?
                        WindowState.Normal : WindowState.Maximized;
                }
            };

            if (Application.Current.MainWindow != null)
            {
                Application.Current.MainWindow.StateChanged += MainWindow_StateChanged;
            }
        }

        public static readonly DependencyProperty ApplicationNameProperty =
            DependencyProperty.Register("ApplicationName", typeof(string), typeof(TopBar), new UIPropertyMetadata(string.Empty));

        public static readonly DependencyProperty ShowWindowControlsProperty =
            DependencyProperty.Register("ShowWindowControls", typeof(bool), typeof(TopBar));
        
        public static readonly DependencyProperty ImageSourceProperty =
            DependencyProperty.Register("ImageSource", typeof(ImageSource), typeof(TopBar));

        public string ApplicationName
        {
            get => (string)GetValue(ApplicationNameProperty);
            set => SetValue(ApplicationNameProperty, value);
        }

        public bool ShowWindowControls
        {
            get => (bool)GetValue(ShowWindowControlsProperty);
            set => SetValue(ShowWindowControlsProperty, value);
        }

        public ImageSource ImageSource
        {
            get => (ImageSource)GetValue(ImageSourceProperty);
            set => SetValue(ImageSourceProperty, value);
        }
        
        public Visibility ShouldShowLogo => (ImageSource != null) ? Visibility.Collapsed : Visibility.Visible;

        private void Minimize_OnClick(object sender, RoutedEventArgs e)
        {
            if (Application.Current.MainWindow != null)
            {
                Application.Current.MainWindow.WindowState = WindowState.Minimized;
            }
        }

        private void Restore_OnClick(object sender, RoutedEventArgs e)
        {
            if (Application.Current.MainWindow != null)
            {
                Application.Current.MainWindow.WindowState = Application.Current.MainWindow.WindowState == WindowState.Maximized ?
                    WindowState.Normal : WindowState.Maximized;
            }
        }

        private void Close_OnClick(object sender, RoutedEventArgs e)
        {
            if (Application.Current.MainWindow != null)
            {
                Application.Current.MainWindow.Close();
            }
        }

        private void MainWindow_StateChanged(object sender, System.EventArgs e)
        {
            if (Application.Current.MainWindow == null)
            {
                return;
            }

            MaximizeButton.Image = Application.Current.MainWindow.WindowState == WindowState.Maximized
                     ? IconType.caret_down_16
                     : IconType.caret_up_16;
        }

        private void IconArea_OnMouseUp(object sender, MouseButtonEventArgs e)
        {
            // TODO: should we fire up system menu on logo click or not?
            //Utils.WindowInterop.ShowSystemMenu(e);
            //e.Handled = true;
        }

        private void Grid_MouseRightButtonUp(object sender, MouseButtonEventArgs e)
        {
            Utils.WindowInterop.ShowSystemMenu(e);
            e.Handled = true;
        }
    }
}
