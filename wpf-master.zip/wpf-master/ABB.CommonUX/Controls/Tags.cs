﻿using System;
using System.Collections;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;

namespace ABB.CommonUX.Controls
{
    public class Tags : ComboBox
    {
        private readonly ObservableCollection<object> _selectedTags = new ObservableCollection<object>();

        public IEnumerable SelectedTags
        {
            get => (IEnumerable)GetValue(SelectedTagsProperty);
            set => SetValue(SelectedTagsProperty, value);
        }

        public ICommand RemoveTagCommand
        {
            get => (ICommand)GetValue(RemoveTagCommandProperty);
            set => SetValue(RemoveTagCommandProperty, value);
        }

        public Tags()
        {
            SelectionChanged += Tags_SelectionChanged;
            PreviewMouseWheel += Tags_MouseWheel;
            SetValue(SelectedTagsProperty, _selectedTags);

            RemoveTagCommand = new RoutedCommand("RemoveTagCommand", typeof(Tags));
            var binding = new CommandBinding { Command = RemoveTagCommand };
            binding.Executed += RemoveTagCommand_Executed;
            CommandBindings.Add(binding);

            // Listen if ItemsSources gets changed.
            var itemsSourceProperty = DependencyPropertyDescriptor.FromProperty(ItemsSourceProperty, typeof(Tags));
            itemsSourceProperty?.AddValueChanged(this, ItemsSourceChanged);

            var selectedTagsProperty = DependencyPropertyDescriptor.FromProperty(SelectedTagsProperty, typeof(Tags));
            selectedTagsProperty?.AddValueChanged(this, ItemsSourceChanged);

            SetResourceReference(StyleProperty, "AbbNormalTagStyle");

            PreviewKeyDown += Tags_KeyDown;        
            LostFocus += Tags_LostFocus;
        }

        private void Tags_MouseWheel(object sender, MouseWheelEventArgs e)
        {
            // Disable mouse wheel. ComboBox does selection with it.
            e.Handled = true;
        }

        private void Tags_LostFocus(object sender, RoutedEventArgs e)
        {
            var binding = BindingOperations.GetBindingExpression(this, Tags.TextProperty);
            binding?.UpdateSource();
            Text = string.Empty;
        }

        private void Tags_KeyDown(object sender, KeyEventArgs e)
        {
            if(!IsEditable)
            {
                return;
            }

            if (e.Key == Key.Enter)
            {
                var binding = BindingOperations.GetBindingExpression(this, Tags.TextProperty);
                binding?.UpdateSource();
                Text = string.Empty;
            }
            else if(e.Key == Key.Back && string.IsNullOrEmpty(Text))
            {
                // Remove last tag when hitting backspace.
                var selectedView = CollectionViewSource.GetDefaultView(GetValue(SelectedTagsProperty));
                if (selectedView.SourceCollection is IList selectedTags &&
                    selectedTags.Count > 0)
                {                    
                    selectedTags.RemoveAt(selectedTags.Count - 1);
                    var view = CollectionViewSource.GetDefaultView(GetValue(ItemsSourceProperty));
                    view?.Refresh();
                }

            }
        }

        private void ItemsSourceChanged(object sender, EventArgs e)
        {
            // Add filter to ItemsSource that filters out already selected tags.
            var view = CollectionViewSource.GetDefaultView(GetValue(ItemsSourceProperty));
            if(view != null)
            {
                var selectedView = CollectionViewSource.GetDefaultView(GetValue(SelectedTagsProperty));                
                if (selectedView != null)
                {
                    view.Filter = (o) => !selectedView.Contains(o);
                }
            }
        }

        private void RemoveTagCommand_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            // Remove clicked tag from selected tags and refresh combobox.
            var selectedView = CollectionViewSource.GetDefaultView(GetValue(SelectedTagsProperty));
            if (selectedView.SourceCollection is IList selectedTags)
            {
                selectedTags.Remove(e.Parameter);

                var view = CollectionViewSource.GetDefaultView(GetValue(ItemsSourceProperty));
                view?.Refresh();
            }
        }

        private void Tags_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Add selected item to tags list and refresh combobox.
            var selectedView = CollectionViewSource.GetDefaultView(GetValue(SelectedTagsProperty));
            var selectedTags = selectedView.SourceCollection as IList;
            if (e.AddedItems.Count > 0)
            {
                if (selectedTags != null && !selectedTags.Contains(e.AddedItems[0]))
                {
                    selectedTags.Add(e.AddedItems[0]);

                    var view = CollectionViewSource.GetDefaultView(GetValue(ItemsSourceProperty));
                    view?.Refresh();
                }
            }
        }

        public static readonly DependencyProperty SelectedTagsProperty =
            DependencyProperty.Register("SelectedTags", typeof(IEnumerable), typeof(Tags));

        public static readonly DependencyProperty RemoveTagCommandProperty =
            DependencyProperty.Register("RemoveTagCommand", typeof(RoutedCommand), typeof(Tags));
    }
}
