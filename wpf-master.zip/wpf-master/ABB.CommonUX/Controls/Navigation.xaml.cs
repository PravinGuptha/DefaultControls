﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Markup;

namespace ABB.CommonUX.Controls
{
    [ContentProperty(nameof(Children))]
    public partial class Navigation : UserControl
    {
        public Navigation()
        {
            InitializeComponent();
            Children = PART_Host.Children;
        }

        public static readonly DependencyPropertyKey ChildrenProperty = DependencyProperty.RegisterReadOnly(
            nameof(Children), typeof(UIElementCollection), typeof(Navigation), new PropertyMetadata());

        public UIElementCollection Children
        {
            get => (UIElementCollection)GetValue(ChildrenProperty.DependencyProperty);
            private set => SetValue(ChildrenProperty, value);
        }
    }
}
