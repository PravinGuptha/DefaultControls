﻿using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using ABB.CommonUX.Controls;

namespace ABB.CommonUX.TestApp
{
    /// <summary>
    /// Interaction logic for Buttons.xaml
    /// </summary>
    public partial class Buttons : UserControl
    {
        public Buttons()
        {
            InitializeComponent();

            var generateButton = new List<string>
            {
                "AbbNormalButtonSmall", "AbbNormalButtonMedium", "AbbNormalButtonLarge",
                "AbbPrimaryButtonSmall", "AbbPrimaryButtonMedium", "AbbPrimaryButtonLarge",
                "AbbPrimaryBlackButtonSmall", "AbbPrimaryBlackButtonMedium", "AbbPrimaryBlackButtonLarge",
                "AbbDiscreetButtonSmall", "AbbDiscreetButtonMedium", "AbbDiscreetButtonLarge",
                "AbbDiscreetBlackButtonSmall", "AbbDiscreetBlackButtonMedium", "AbbDiscreetBlackButtonLarge",
            };

            var generateIconButton = new List<string>
            {
                "AbbNormalIconButtonSmall", "AbbNormalIconButtonMedium", "AbbNormalIconButtonLarge",
                "AbbPrimaryIconButtonSmall", "AbbPrimaryIconButtonMedium", "AbbPrimaryIconButtonLarge",
                "AbbPrimaryBlackIconButtonSmall", "AbbPrimaryBlackIconButtonMedium", "AbbPrimaryBlackIconButtonLarge",
                "AbbDiscreetIconButtonSmall", "AbbDiscreetIconButtonMedium", "AbbDiscreetIconButtonLarge",
                "AbbDiscreetBlackIconButtonSmall", "AbbDiscreetBlackIconButtonMedium", "AbbDiscreetBlackIconButtonLarge",
            };

            const double thick = 5;

            foreach (var buttonName in generateButton)
            {
                ButtonsPanel.RowDefinitions.Add(new RowDefinition());

                var button = new Button {Margin = new Thickness(thick), Content = "Button"};
                button.SetResourceReference(Button.StyleProperty, buttonName);
                button.ToolTip = buttonName;
                ButtonsPanel.Children.Add(button);
                Grid.SetRow(button, ButtonsPanel.RowDefinitions.Count - 1);
                Grid.SetColumn(button, 0);

                button = new Button {Margin = new Thickness(thick), Content = "Button"};
                button.SetResourceReference(Button.StyleProperty, buttonName);
                button.IsEnabled = false;
                button.ToolTip = buttonName;
                ButtonsPanel.Children.Add(button);
                Grid.SetRow(button, ButtonsPanel.RowDefinitions.Count - 1);
                Grid.SetColumn(button, 1);
            }

            int row = 0;
            foreach (var iconName in generateIconButton)
            {
                var icon = new IconButton { Margin = new Thickness(thick), Content = "Button" };
                icon.SetResourceReference(Button.StyleProperty, iconName);
                icon.Image = IconType.check_mark_circle_2_16;
                icon.ToolTip = iconName;
                ButtonsPanel.Children.Add(icon);
                Grid.SetRow(icon, row);
                Grid.SetColumn(icon, 2);

                icon = new IconButton { Margin = new Thickness(thick), Content = "Button" };
                icon.SetResourceReference(Button.StyleProperty, iconName);
                icon.IsEnabled = false;
                icon.Image = IconType.check_mark_circle_2_16;
                icon.ToolTip = iconName;
                ButtonsPanel.Children.Add(icon);
                Grid.SetRow(icon, row);
                Grid.SetColumn(icon, 3);

                icon = new IconButton { Margin = new Thickness(thick) };
                icon.SetResourceReference(Button.StyleProperty, iconName);
                icon.ToolTip = iconName;
                icon.Image = IconType.check_mark_circle_2_16;
                ButtonsPanel.Children.Add(icon);
                Grid.SetRow(icon, row);
                Grid.SetColumn(icon, 4);

                icon = new IconButton { Margin = new Thickness(thick) };
                icon.SetResourceReference(Button.StyleProperty, iconName);
                icon.IsEnabled = false;
                icon.Image = IconType.check_mark_circle_2_16;
                icon.ToolTip = iconName;
                ButtonsPanel.Children.Add(icon);
                Grid.SetRow(icon, row++);
                Grid.SetColumn(icon, 5);
            }
        }
    }
}
