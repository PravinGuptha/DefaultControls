﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace ABB.CommonUX.TestApp
{
    /// <summary>
    /// Interaction logic for Misc.xaml
    /// </summary>
    public partial class Misc : UserControl
    {
        public Misc()
        {
            InitializeComponent();
        }

        private void NavigationItem_OnChecked(object sender, EventArgs e)
        {
            MessageBox.Show(Application.Current.MainWindow, "Navigation", "Navigation happened.");
        }

        private void MenuItem_OnClick(object sender, RoutedEventArgs e)
        {
        }
    }
}
