﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Animation;
using System.Windows.Threading;

namespace ABB.CommonUX.Controls
{
    public partial class Notification : UserControl
    {
        public event EventHandler NotificationClose;

        private readonly DispatcherTimer _closeTimer;

        public Notification(string message, Notifications.NotificationType type, int timeoutMs = 5000)
        {
            InitializeComponent();

            MessageText.Text = message;

            switch (type)
            {
                case Notifications.NotificationType.Information:
                    NotificationBorder.SetResourceReference(Border.BackgroundProperty, "Notification.Info.Accent.Brush");
                    NotificationBorder.SetResourceReference(Border.BorderBrushProperty, "Notification.Info.Accent.Brush");
                    MessageText.SetResourceReference(TextBlock.ForegroundProperty, "Notification.Info.Foreground.Brush");
                    CloseButton.SetResourceReference(Icon.ForegroundProperty, "Notification.Info.Foreground.Brush");
                    icon.SetResourceReference(ForegroundProperty, "Notification.Warning.Foreground.Brush");
                    icon.Image = IconType.information_circle_1_16;
                    break;
                case Notifications.NotificationType.Warning:
                    NotificationBorder.SetResourceReference(Border.BackgroundProperty, "Notification.Warning.Accent.Brush");
                    NotificationBorder.SetResourceReference(Border.BorderBrushProperty, "Notification.Warning.Accent.Brush");
                    MessageText.SetResourceReference(TextBlock.ForegroundProperty, "Notification.Warning.Foreground.Brush");
                    CloseButton.SetResourceReference(Icon.ForegroundProperty, "Notification.Warning.Foreground.Brush");
                    icon.SetResourceReference(ForegroundProperty, "Notification.Warning.Foreground.Brush");
                    icon.Image = IconType.warning_circle_1_16;
                    break;
                case Notifications.NotificationType.Error:
                    NotificationBorder.SetResourceReference(Border.BackgroundProperty, "Notification.Error.Accent.Brush");
                    NotificationBorder.SetResourceReference(Border.BorderBrushProperty, "Notification.Error.Accent.Brush");
                    MessageText.SetResourceReference(TextBlock.ForegroundProperty, "Notification.Error.Foreground.Brush");
                    CloseButton.SetResourceReference(Icon.ForegroundProperty, "Notification.Error.Foreground.Brush");
                    icon.SetResourceReference(ForegroundProperty, "Notification.Warning.Foreground.Brush");
                    icon.Image = IconType.error_circle_1_16;
                    break;
                case Notifications.NotificationType.Confirmation:
                    NotificationBorder.SetResourceReference(Border.BackgroundProperty, "Notification.Confirm.Accent.Brush");
                    NotificationBorder.SetResourceReference(Border.BorderBrushProperty, "Notification.Confirm.Accent.Brush");
                    MessageText.SetResourceReference(TextBlock.ForegroundProperty, "Notification.Confirm.Foreground.Brush");
                    CloseButton.SetResourceReference(Icon.ForegroundProperty, "Notification.Confirm.Foreground.Brush");
                    icon.SetResourceReference(ForegroundProperty, "Notification.Warning.Foreground.Brush");
                    icon.Image = IconType.check_mark_circle_1_16;
                    break;
                case Notifications.NotificationType.ConfirmationDiscreet:
                    NotificationBorder.SetResourceReference(Border.BackgroundProperty, "Notification.Background.Brush");
                    NotificationBorder.SetResourceReference(Border.BorderBrushProperty, "Notification.Border.Brush");
                    MessageText.SetResourceReference(TextBlock.ForegroundProperty, "Notification.Foreground.Brush");
                    CloseButton.SetResourceReference(Icon.ForegroundProperty, "Notification.Foreground.Brush");
                    icon.SetResourceReference(ForegroundProperty, "Notification.Confirm.Accent.Brush");
                    icon.Image = IconType.check_mark_circle_1_16;
                    break;
                case Notifications.NotificationType.InformationDiscreet:
                    NotificationBorder.SetResourceReference(Border.BackgroundProperty, "Notification.Background.Brush");
                    NotificationBorder.SetResourceReference(Border.BorderBrushProperty, "Notification.Border.Brush");
                    MessageText.SetResourceReference(TextBlock.ForegroundProperty, "Notification.Foreground.Brush");
                    CloseButton.SetResourceReference(Icon.ForegroundProperty, "Notification.Foreground.Brush");
                    icon.SetResourceReference(ForegroundProperty, "Notification.Info.Accent.Brush");
                    icon.Image = IconType.information_circle_1_16;
                    break;
                case Notifications.NotificationType.WarningDiscreet:
                    NotificationBorder.SetResourceReference(Border.BackgroundProperty, "Notification.Background.Brush");
                    NotificationBorder.SetResourceReference(Border.BorderBrushProperty, "Notification.Border.Brush");
                    MessageText.SetResourceReference(TextBlock.ForegroundProperty, "Notification.Foreground.Brush");
                    CloseButton.SetResourceReference(Icon.ForegroundProperty, "Notification.Foreground.Brush");
                    icon.SetResourceReference(ForegroundProperty, "Notification.Warning.Accent.Brush");
                    icon.Image = IconType.warning_circle_1_16;
                    break;
                case Notifications.NotificationType.ErrorDiscreet:
                    NotificationBorder.SetResourceReference(Border.BackgroundProperty, "Notification.Background.Brush");
                    NotificationBorder.SetResourceReference(Border.BorderBrushProperty, "Notification.Border.Brush");
                    MessageText.SetResourceReference(TextBlock.ForegroundProperty, "Notification.Foreground.Brush");
                    CloseButton.SetResourceReference(Icon.ForegroundProperty, "Notification.Foreground.Brush");
                    icon.SetResourceReference(ForegroundProperty, "Notification.Error.Accent.Brush");
                    icon.Image = IconType.error_circle_1_16;
                    break;
                default:
                    throw new ArgumentOutOfRangeException(nameof(type), type, null);
            }

            // Close window after timeout.
            _closeTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(timeoutMs) };
            _closeTimer.Start();
            _closeTimer.Tick += (sender, args) =>
            {
                AnimateClose();                
            };
        }

        private void Notification_OnMouseEnter(object sender, MouseEventArgs e)
        {
            // Stop timer on mouse enter. User has to close notification with close button.
            _closeTimer.Stop();
        }

        private void CloseButton_OnClick(object sender, RoutedEventArgs e)
        {
            AnimateClose();
        }

        private void AnimateClose()
        {
            // Play window closing animation and close.
            var sb = FindResource("WindowCloseAnimation") as Storyboard;
            sb.Completed += (o, eventArgs) =>
            {
                NotificationClose?.Invoke(this, EventArgs.Empty);
            };
            sb.Begin();
        }
    }
}
