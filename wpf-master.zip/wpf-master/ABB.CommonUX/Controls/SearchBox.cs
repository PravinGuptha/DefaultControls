﻿using System.Windows.Controls;

namespace ABB.CommonUX.Controls
{
    public class SearchBox : TextBox
    {        
    }
}
