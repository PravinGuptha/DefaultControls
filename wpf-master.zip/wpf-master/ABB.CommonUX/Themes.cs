﻿using System;
using System.Linq;
using System.Windows;

namespace ABB.CommonUX
{
    /// <summary>
    /// Themes class handles changing between dark and light themes.
    /// </summary>
    public static class Themes
    {
        public enum Theme { Light, Dark } // Don't change these. They are used as strings in ChangeTheme.

        /// <summary>
        /// Gets the currently used theme.
        /// </summary>
        /// <param name="app"></param>
        /// <returns></returns>
        public static Theme GetCurrentTheme(Application app)
        {
            return app.Resources.MergedDictionaries.Any(d => d.Source.OriginalString.Contains("Light.xaml")) ? Theme.Light : Theme.Dark;
        }

        /// <summary>
        /// Changes application color theme.
        /// </summary>
        /// <param name="app">Application object. Ex. Application.Current.</param>
        /// <param name="theme">New theme</param>
        public static void ChangeTheme(Application app, Theme theme)
        {
            var currentTheme = GetCurrentTheme(app);
            if (currentTheme == theme)
            {
                return;
            }

            var rd = app.Resources.MergedDictionaries.FirstOrDefault(d => d.Source.OriginalString.Contains($"{currentTheme}.xaml"));
            app.Resources.MergedDictionaries.Remove(rd);

            app.Resources.MergedDictionaries.Add(new ResourceDictionary
            {
                Source = new Uri($"pack://application:,,,/ABB.CommonUX;component/Themes/{theme}.xaml")
            });                    
        }
    }
}
